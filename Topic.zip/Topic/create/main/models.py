from django.db import models




class HomeTitle(models.Model):
    title=models.CharField('title',max_length=255)
    subtitle=models.CharField('Subtitle',max_length=255)

    def __str__(self) -> str:
        return self.title
    
    class Meta:
        verbose_name='Home Title'
        verbose_name_plural='Home Title'



class Introduction(models.Model):
    title=models.CharField('Title',max_length=255)
    text=models.TextField('information')
    img=models.ImageField('Images',upload_to="Home_Media")


    def __str__(self) -> str:
        return self.title
    

    class Meta:
        verbose_name='Introduction'
        verbose_name_plural='Introductions'



class Finance(models.Model):
    title=models.CharField('Title',max_length=255)
    text=models.TextField('information')
    img=models.ImageField('Images',upload_to="Home_Media")
    twitter=models.URLField('Twitter')
    facebook=models.URLField('facebook')
    pinterest=models.URLField('pinterest')
    youtube=models.URLField('Youtube',null=True)


    def __str__(self) -> str:
        return self.title
    


class Chapter(models.Model):
    name=models.CharField('Chapter',max_length=50)

    def __str__(self) -> str:
        return self.name
    

class SubChapter(models.Model):
    chapthertwo=models.ForeignKey(Chapter,on_delete=models.CASCADE,related_name='subchapter_related')
    title=models.CharField('Title',max_length=255)
    text=models.TextField('Text')
    img=models.ImageField('image',upload_to='Home_Media')
    point=models.IntegerField('Point',null=True)


    def __str__(self) -> str:
        return self.title
    
    class Meta:
        ordering=['id']
        verbose_name='Subchapter'
        verbose_name_plural='Subchapters'


class HowItWork(models.Model):
    icon=models.CharField('Icon name',max_length=255)
    title=models.CharField('Title',max_length=255)
    text=models.TextField('Text')


    def __str__(self) -> str:
        return self.title
    

    class Meta:
        verbose_name='How it work'
        verbose_name_plural="How it work"



class Asked(models.Model):
    title=models.CharField('Title',max_length=50)
    text=models.TextField('text',null=True)
    img=models.ImageField('images',null=True)


    def __str__(self) -> str:
        return self.title

# class SubAsked(models.Model):
#     subask=models.ForeignKey(Asked,on_delete=models.CASCADE,related_name='subasked_related')
#     text=models.TextField('text')


#     def __str__(self) -> str:
#         return self.text



class Communicate(models.Model):
    place=models.CharField('Place',max_length=255)
    address=models.CharField('Address',max_length=255)
    phone=models.IntegerField('Phone')
    Email=models.EmailField('Email')


    def __str__(self) -> str:
        return self.place
    
    class Meta:
        verbose_name='Communicate'
        verbose_name_plural='Communicates'


class Detals(models.Model):
    detal=models.ForeignKey(SubChapter,on_delete=models.CASCADE,related_name='detal_related')
    title=models.CharField('Title',max_length=255)
    info1=models.TextField('Information 1')
    info2=models.TextField('Information 2')
    subtitle=models.CharField('Subtitle',max_length=255)
    img1=models.ImageField('images1',upload_to='Detal Images')
    img2=models.ImageField('images2',upload_to='Detal Images',blank=True)
    text=models.TextField('Text')


    def __str__(self) -> str:
        return self.title
    

    class Meta:
        verbose_name='Detal'
        verbose_name_plural="Detals"


class DetalForm(models.Model):
    email=models.EmailField('Email Address')


    def __str__(self) -> str:
        return self.email




class ContactForm(models.Model):
    name=models.CharField('name',max_length=50)
    email=models.EmailField('email')
    subject=models.CharField('Subject',max_length=255)
    message=models.TextField('Message')


    def __str__(self) -> str:
        return self.name
    
    class Meta:
        verbose_name='Contact Form'
        verbose_name_plural='Contact Forms'
































