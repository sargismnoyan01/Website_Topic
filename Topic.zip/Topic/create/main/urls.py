from django.urls import path
from .views import *

urlpatterns=[
    path('',HomeListViews.as_view(),name='home'),
    path('<int:id>/',DetalesView.as_view(),name='detales'),
    path('listing/',Listing.as_view(),name='list'),
    path('contact/',ContactListViews.as_view(),name='contact'),
    path('register/',RegisterPage,name='register'),
    path('login/',LoginPage,name='login'),
    path('logout',logout_request,name='logout')

    
    
    
]