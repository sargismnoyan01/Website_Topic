from django.shortcuts import redirect, render
from django.views.generic import ListView,DeleteView
from .models import *
from .forms import *
from django.core.mail import EmailMessage
from create.settings import EMAIL_HOST_USER
from django.contrib.auth import authenticate,login,logout

class HomeListViews(ListView):
    template_name='index.html'

    def get(self,request):
        hometitle=HomeTitle.objects.get()
        introduction=Introduction.objects.get()
        finance=Finance.objects.get()
        chapter=Chapter.objects.all()
        chapter_first=Chapter.objects.first()
        subchapter=SubChapter.objects.all()
        subchapter_first=SubChapter.objects.first()
        form=DetalForm()
        howitwork=HowItWork.objects.all()
        asked=Asked.objects.get()
        communicate=Communicate.objects.all()

        context={
            'form':form,
            'link':'home',
            'hometitle':hometitle,
            'introduction':introduction,
            'finance':finance,
            'chapter':chapter,
            'chapter_first':chapter_first,
            'subchapter':subchapter,
            'howitwork':howitwork,
            'asked':asked,
            'communicate':communicate,
            'subchapter_first':subchapter_first,
            
                }
        
        return render(request,self.template_name,context)

    def post(self,request):
        hometitle=HomeTitle.objects.get()
        introduction=Introduction.objects.get()
        finance=Finance.objects.get()
        chapter=Chapter.objects.all()
        chapter_first=Chapter.objects.first()
        subchapter=SubChapter.objects.all()
        subchapter_first=SubChapter.objects.first()
        howitwork=HowItWork.objects.all()
        asked=Asked.objects.get()
        communicate=Communicate.objects.all()
        form=DetalForm(request.POST)
        subject='Նոր նամակ Topic-ից'

        body=f" Բարև հարգելի, ձեր կարծիքը կարևոր է մեզ համար"

        try:
            form.save()
            email=EmailMessage(
            subject=subject,
            body=body,
            from_email=EMAIL_HOST_USER,
            to=[request.POST.get('email')]
            )
            email.send()
            return redirect('home')
        except Exception:
            form=DetalForm()

        context={
            'form':form,
            'link':'home',
            'hometitle':hometitle,
            'introduction':introduction,
            'finance':finance,
            'chapter':chapter,
            'chapter_first':chapter_first,
            'subchapter':subchapter,
            'howitwork':howitwork,
            'asked':asked,
            'communicate':communicate,
            'subchapter_first':subchapter_first,
            
                }
        return render(request,self.template_name,context)




class DetalesView(DeleteView):
    template_name='topics-detail.html'

    def get(self,request,id):
        chapter=Chapter.objects.all()
        chapter_first=Chapter.objects.first()
        subchapter=SubChapter.objects.all()
        detals=SubChapter.objects.filter(pk=id)
        form=DetalForm()
        context={
            'link':'detales',
            'chapter':chapter,
            'chapter_first':chapter_first,
            'subchapter':subchapter,
            'detals':detals,
            'form':form,
            

                }
        
        return render(request,self.template_name,context)
    
        


class Listing(ListView):
    template_name='topics-listing.html'


    def get(self,request):
        subchapter=SubChapter.objects.all()

        context={
            'link':'Listing',
            'subchapter':subchapter
            }


        return render(request,self.template_name,context)



class ContactListViews(ListView):
    template_name='contact.html'


    def get(self,request):
        form=ContactModelForm()
        communicate=Communicate.objects.all()
        communicate_first=Communicate.objects.first()


        context={
            'link':'contact',
            'form':form,
            'communicate':communicate,
            'communicate_first':communicate_first

                }
        
        return render(request,self.template_name,context)
    

    def post(self,request):
        communicate=Communicate.objects.all()
        communicate_first=Communicate.objects.first()

        form=ContactModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            form=ContactModelForm


        context={
            'form':form,
            'communicate':communicate,
            'communicate_first':communicate_first,

                }
        
        return render(request,self.template_name,context)
    

def RegisterPage(request):
    form=Create()
    if request.method=="POST":
        form=Create(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            form=Create()


    return render(request,'register.html',{'form':form})


def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(username=username,password=password)
        
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return redirect('register')
        
    return render(request,'login.html')

def logout_request(request):
	logout(request)
	return redirect("home")

