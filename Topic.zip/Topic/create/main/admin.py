from django.contrib import admin
from .models import *




admin.site.register(HomeTitle)
admin.site.register(Introduction)
admin.site.register(Finance)
admin.site.register(Chapter)
admin.site.register(HowItWork)
admin.site.register(DetalForm)





@admin.register(SubChapter)
class SubchapterModelAdmin(admin.ModelAdmin):
    list_display=['title','text','point']
    list_display_links=['title','text']
    search_fields=['title','text']


@admin.register(Asked)
class AskedModelAdmin(admin.ModelAdmin):
    list_display=['title','text']
    list_display_links=['title','text']
    search_fields=['title','text']

@admin.register(Communicate)
class CommunicateModelAdmin(admin.ModelAdmin):
    list_display=['place','address','phone']
    list_display_links=['place','address','phone']
    search_fields=['place','address','phone','email']

@admin.register(Detals)
class DetalsModelAdmin(admin.ModelAdmin):
    list_display=['title','subtitle','text','id']
    list_display_links=['title','subtitle','text']
    search_fields=['title','subtitle','text']

@admin.register(ContactForm)
class ContactFormModelAdmin(admin.ModelAdmin):
    list_display=['name','subject','email']
    list_display_links=['name','subject','email']
    search_fields=['name','subject','email','message']























